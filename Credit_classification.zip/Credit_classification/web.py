from flask import Flask,render_template,request
import pickle
import numpy as np
import pandas as pd
from logging import FileHandler,WARNING
from sklearn.preprocessing import LabelEncoder

from sklearn.preprocessing import StandardScaler, OrdinalEncoder, PowerTransformer, FunctionTransformer, OneHotEncoder, LabelEncoder


  

app=Flask(__name__)
model=pickle.load(open('model_credit.pkl','rb'))

@app.route('/')
def home():
    return render_template('home.html')




@app.route('/predict',methods=['POST'])
def predict():
    #custid=int(request.form['cust_id'])
    name = request.form['name']
    age = float(request.form['age'])
    occupation = request.form['occupation']
    annualincome = float(request.form['annualincome'])
    monthlyinhandsalary = float(request.form['monthlyinhandsalary'])
    numberofbankaccounts = float(request.form['numberofbankaccounts'])
    numberofcreditcards =float(request.form['numberofcreditcards'])
    numberofloans = float(request.form['numberofloans'])
    numberofdelayedpayments = float(request.form['numberofdelayedpayments'])
    numberofcreditinquiries = float(request.form['numberofcreditinquiries'])
    outstandingdebt = float(request.form['outstandingdebt'])
    payment_of_min_amount = request.form['payment_of_min_amount']
    total_emi_per_month = float(request.form['total_emi_per_month'])
    amount_invested_monthly = float(request.form['amount_invested_monthly'])
    monthly_balance = float(request.form['monthly_balance'])
       
    le=LabelEncoder()
    name_encoded=le.fit_transform([name])
    
    occupation_encoded=le.fit_transform([occupation])
    
    
    payment_of_min_amount_encoded=le.fit_transform([payment_of_min_amount])
    
    # Make a prediction
    input_features = [name_encoded,age,payment_of_min_amount_encoded,occupation_encoded,annualincome,monthlyinhandsalary,numberofbankaccounts,numberofcreditcards,numberofloans,numberofdelayedpayments,numberofcreditinquiries,outstandingdebt,total_emi_per_month,amount_invested_monthly,monthly_balance]
    
    #creating numpy array
    clean_data = [float(i) for i in input_features]
    # Reshape the Data as a Sample not Individual Features
    ex1 = np.array(clean_data).reshape(1,-1)
    output=model.predict(ex1)
    print(output[0])
    #Good -2-53174
    #Poor-28998-1
    #Standard-17828-0
    if output[0] == 0:
     prediction_string = f"You are  eligible for a loan and your credit score is Standard"
    elif output[0] == 1:
     prediction_string = f"You are not eligible for a loan and your credit score is Poor"
    elif output[0] == 2:
     prediction_string = f"You are eligible for a loan and your credit score is Good"

     
    return render_template('res.html',prediction_text=prediction_string)

""" def leave_one_out_encoding(input_data, target):
    encoded_data = {}
    
    for column, values in input_data.items():
        encoded_column = column
        encoded_data[encoded_column] = []
        
        for value in values:
            # Leave one out mean
            encoded_data[column] = ce.LeaveOneOutEncoder().fit_transform(encoded_data[column],target)
            # Append the leave-one-out mean to the encoded data
            encoded_data[encoded_column].append(leave_one_out_mean)
        
    return pd.DataFrame(encoded_data) """



if __name__ == '__main__':
    app.run(debug=True,port=8000)




#app.run(debug=True,port=8000)