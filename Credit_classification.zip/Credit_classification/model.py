import pandas as pd
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier 
df_creditdata=pd.read_csv("final_datacredit.csv")
#X=df_creditdata[['Customer_ID','Annual_Income','Age','SSN','Occupation','Annual_Income', 'Monthly_Inhand_Salary', 'Num_Bank_Accounts','Num_Credit_Card', 'Interest_Rate', 'Num_of_Loan','Num_Credit_Card','Interest_Rate','Delay_from_due_date','Num_of_Delayed_Payment','Monthly_Balance',
#'Num_Credit_Inquiries','Changed_Credit_Limit','Credit_History_Age','Outstanding_Debt','Total_EMI_per_month','Amount_invested_monthly', 'Payment_Behaviour']]
#X=df_creditdata.drop('Credit_Score',axis=1)
#taking necessary features
X=df_creditdata[['Name','Age','Occupation','Annual_Income', 'Monthly_Inhand_Salary', 'Num_Bank_Accounts','Num_Credit_Card', 'Num_of_Loan','Num_of_Delayed_Payment',
'Num_Credit_Inquiries','Outstanding_Debt','Payment_of_Min_Amount','Total_EMI_per_month','Amount_invested_monthly', 'Monthly_Balance']]

X=df_creditdata.drop('Credit_Score',axis=1)
y = df_creditdata.Credit_Score


#scaler = StandardScaler()
#X = scaler.fit_transform(X)

#from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
#X = scaler.fit_transform(X)

X_train, X_test,y_train,y_test=train_test_split(X,y,test_size=0.20,random_state=42)

#from sklearn.tree import DecisionTreeClassifier

#clf=DecisionTreeClassifier(criterion='entropy',max_depth=3)
#clf=clf.fit(X_train,y_train)
#y_pred=clf.predict(X_test)
model_1 = RandomForestClassifier(
    n_estimators=10,  # Number of trees in the forest
    criterion='entropy',       # Maximum depth of the trees
    random_state=42      # Random seed for reproducibility
)
# Train the model
model_1.fit(X_train, y_train)

# Make predictions on validation data


rf_predict=model_1.predict(X_test)


accuracy = accuracy_score(y_test, rf_predict)*100
print('Accuracy is ' + str(round(accuracy, 2)) + ' %.')
#pickle.dump(clf,open('model_credit.pkl','wb'))
pickle.dump(model_1,open('model_credit.pkl','wb'))