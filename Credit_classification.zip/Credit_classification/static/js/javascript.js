function clearArea(){
  document.getElementById("inputhead").reset();
}


function validateForm(){
  var nametext = document.getElementById("name").value;
  document.getElementById("namevalidationtxt").innerHTML = "";
  
   var agetext = document.getElementById("age").value;
  document.getElementById("agevalidationtxt").innerHTML = "";
  
   var occupationtext = document.getElementById("occupation").value;
  document.getElementById("occupationvalidationtxt").innerHTML = "";
  
   var annualincometext = document.getElementById("annualincome").value;
  document.getElementById("annualincomevalidationtxt").innerHTML = "";
  
   var monthlyinhandsalarytext = document.getElementById("monthlyinhandsalary").value;
  document.getElementById("monthlyinhandsalaryvalidationtxt").innerHTML = "";
  
   var numberofbankaccountstext = document.getElementById("numberofbankaccounts").value;
  document.getElementById("numberofbankaccountsvalidationtxt").innerHTML = "";
  
    var numberofcreditcardstext = document.getElementById("numberofcreditcards").value;
  document.getElementById("numberofcreditcardsvalidationtxt").innerHTML = "";
  
  
  
    var numberofloanstext = document.getElementById("numberofcreditcards").value;
  document.getElementById("numberofloansvalidationtxt").innerHTML = "";
  
   var numberofdelayedpaymentstext = document.getElementById("numberofdelayedpayments").value;
  document.getElementById("numberofdelayedpaymentsvalidationtxt").innerHTML = "";
  
   var numberofcreditinquiriestext = document.getElementById("numberofcreditinquiries").value;
  document.getElementById("numberofcreditinquiriesvalidationtxt").innerHTML = "";
  
   var outstandingdebttext = document.getElementById("outstandingdebt").value;
  document.getElementById("outstandingdebtvalidationtxt").innerHTML = "";
  
  var payment_of_min_amounttext = document.getElementById("payment_of_min_amount").value;
  document.getElementById("payment_of_min_amountvalidationtxt").innerHTML = "";
  
   var total_emi_per_monthtext = document.getElementById("total_emi_per_month").value;
  document.getElementById("total_emi_per_monthvalidationtxt").innerHTML = "";
  
  var amount_invested_monthlytext = document.getElementById("amount_invested_monthly").value;
  document.getElementById("amount_invested_monthlyvalidationtxt").innerHTML = "";
  
  var monthly_balancetext = document.getElementById("monthly_balance").value;
  document.getElementById("monthly_balancevalidationtxt").innerHTML = "";
  
  if (nametext.trim() === ''){
    document.getElementById("namevalidationtxt").innerHTML = "<b>Missing the name !!!,<br> Please enter the name of customer.</b>";
 
      return false;
  }
   
  
    if (agetext.trim() === ''){
    document.getElementById("agevalidationtxt").innerHTML = "<b>Missing age !!!,<br> Please enter the age of customer.</b>";
  
      return false;
  }
  if(isNaN(agetext)){
	   document.getElementById("namevalidationtxt").innerHTML = "";
	   document.getElementById("namevalidationtxt").innerHTML ="Please enter a integer or flaot number"
	    return false;
  }
  
  
    if (occupationtext.trim() === ''){
    document.getElementById("occupationvalidationtxt").innerHTML = "<b>Missing Occupation !!!,<br> Please enter the Occupation of customer.</b>";
  
      return false;
  }
    
  
  
  
    if (annualincometext.trim() === ''){
    document.getElementById("annualincomevalidationtxt").innerHTML = "<b>Missing Annual Income !!!,<br> Please enter Annual Income of customer.</b>";
  
      return false;
  }
  
  if(isNaN(annualincometext)){
	   document.getElementById("annualincomevalidationtxt").innerHTML = "";
	   document.getElementById("annualincomevalidationtxt").innerHTML ="Please enter a integer or flaot number"
	    return false;
  }
  
  
   if (monthlyinhandsalarytext.trim() === ''){
    document.getElementById("monthlyinhandsalaryvalidationtxt").innerHTML = "<b>Missing Monthly Salary !!!,<br> Please enter Monthly Salary customer.</b>";
  
      return false;
  }
    
  if(isNaN(monthlyinhandsalarytext)){
	   document.getElementById("monthlyinhandsalaryvalidationtxt").innerHTML = "";
	   document.getElementById("monthlyinhandsalaryvalidationtxt").innerHTML ="Please enter a integer or flaot number"
	    return false;
  }
  
  
  
      if (numberofbankaccountstext.trim() === ''){
    document.getElementById("numberofbankaccountsvalidationtxt").innerHTML = "<b>Missing No of accounts !!!,<br> Please enter Number of Bank Accounts.</b>";
  
      return false;
  }
      if(isNaN(numberofbankaccountstext)){
	   document.getElementById("numberofbankaccountsvalidationtxt").innerHTML = "";
	   document.getElementById("numberofbankaccountsvalidationtxt").innerHTML ="Please enter a integer or flaot number"
	    return false;
  }
  
  
     
      if (numberofcreditcardstext.trim() === ''){
    document.getElementById("numberofcreditcardsvalidationtxt").innerHTML = "<b>Missing No of cards value !!!,<br> Please enter No. of Credit cards of .</b>";
  
      return false;
  }
    if(isNaN(numberofcreditcardstext)){
	   document.getElementById("numberofcreditcardsvalidationtxt").innerHTML = "";
	   document.getElementById("numberofcreditcardsvalidationtxt").innerHTML ="Please enter a integer or flaot number"
	    return false;
  }
  
  
      if (numberofloanstext.trim() === ''){
    document.getElementById("numberofloansvalidationtxt").innerHTML = "<b>Missing No of Loans !!!,<br> Please enter No of Loans of customer.</b>";
  
      return false;
  }
  if(isNaN(numberofloanstext)){
	   document.getElementById("numberofloansvalidationtxt").innerHTML = "";
	   document.getElementById("numberofloansvalidationtxt").innerHTML ="Please enter a integer or flaot number"
	    return false;
  }
  
  
   if (numberofcreditinquiriestext.trim() === ''){
    document.getElementById("numberofcreditinquiriesvalidationtxt").innerHTML = "<b>Missing No of Credit Inquiries !!!,<br> Please enter No of Credit Inquiries of customer.</b>";
  
      return false;
  }
  if(isNaN(numberofcreditinquiriestext)){
	   document.getElementById("numberofcreditinquiriesvalidationtxt").innerHTML = "";
	   document.getElementById("numberofcreditinquiriesvalidationtxt").innerHTML ="Please enter a integer or flaot number"
	    return false;
  }
  
  
  if (outstandingdebttext.trim() === ''){
    document.getElementById("outstandingdebtvalidationtxt").innerHTML = "<b>Missing Oustanding Debt !!!,<br> Please enter Oustanding debt of customer.</b>";
  
      return false;
  }
  if (payment_of_min_amounttext.trim() === ''){
    document.getElementById("payment_of_min_amountvalidationtxt").innerHTML = "<b>Missing Payment of min amt !!!,<br> Please enter Payment of Min amt.</b>";
  
      return false;
  }
   if (total_emi_per_monthtext.trim() === ''){
    document.getElementById("total_emi_per_monthvalidationtxt").innerHTML = "<b>Missing Total emi !!!,<br> Please enter Total emi per month.</b>";
  
      return false;
  }
   if(isNaN(total_emi_per_monthtext)){
	   document.getElementById("total_emi_per_monthvalidationtxt").innerHTML = "";
	   document.getElementById("total_emi_per_monthvalidationtxt").innerHTML ="Please enter a integer or flaot number"
	    return false;
  }
  
   if (amount_invested_monthlytext.trim() === ''){
    document.getElementById("amount_invested_monthlyvalidationtxt").innerHTML = "<b>Missing Amount invested !!!,<br> Please enter Amount Invested Monthly.</b>";
  
      return false;
  }
  if(isNaN(amount_invested_monthlytext)){
	   document.getElementById("amount_invested_monthlyvalidationtxt").innerHTML = "";
	   document.getElementById("amount_invested_monthlyvalidationtxt").innerHTML ="Please enter a integer or flaot number"
	    return false;
  }
  
  
   if (monthly_balancetext.trim() === ''){
    document.getElementById("monthly_balancevalidationtxt").innerHTML = "<b>Missing Monthly Balance !!!,<br> Please enter monthly_balance .</b>";
  
      return false;
  }
  if(isNaN(monthly_balancetext)){
	   document.getElementById("monthly_balancevalidationtxt").innerHTML = "";
	   document.getElementById("monthly_balancevalidationtxt").innerHTML ="Please enter a integer or flaot number"
	    return false;
  }
  
  return true;
}


