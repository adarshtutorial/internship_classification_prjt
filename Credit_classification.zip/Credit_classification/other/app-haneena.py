from flask import Flask, render_template, request
import pickle
import numpy as np
# Load the trained model from the file
model=pickle.load(open('model.pkl','rb'))
app = Flask(__name__)

# Route for home page
@app.route('/')
def home():
    return render_template('home.html')

# Route for prediction
@app.route('/predict', methods=['POST'])
def predict():
    
  
    
    # Get input data
    age = float(request.form['age'])
    annual_income = float(request.form['annual_income'])
    monthly_inhand_salary = float(request.form['monthly_inhand_salary'])
    num_bank_accounts = float(request.form['num_bank_accounts'])
    num_credit_card = float(request.form['num_credit_card'])
    num_of_loan = float(request.form['num_of_loan'])
    delay_from_due_date =float(request.form['delay_from_due_date'])
    num_of_delayed_payment = float(request.form['num_of_delayed_payment'])
    num_credit_inquiries = float(request.form['num_credit_inquiries'])
    outstanding_debt = float(request.form['outstanding_debt'])
    total_emi_per_month = float(request.form['total_emi_per_month'])
    amount_invested_monthly = float(request.form['amount_invested_monthly'])
    monthly_balance = float(request.form['monthly_balance'])
    occupation= request.form['occupation']
    credit_mix = request.form['credit_mix']
    payment_of_min_amount= request.form['payment_of_min_amount']
    payment_behaviour= request.form['payment_behaviour']
    print(occupation)
    # Encode categorical variables
    from sklearn.preprocessing import LabelEncoder
    le=LabelEncoder()
    Occupation_encoded=le.fit_transform(occupation)
    Credit_Mix_encoded=le.fit_transform(credit_mix)
    Payment_of_Min_Amount_encoded=le.fit_transform(payment_of_min_amount)
    Payment_Behaviour_encoded=le.fit_transform(payment_behaviour)
   
    form_data ={
    'Payment_of_Min_Amount_encoded': Payment_of_Min_Amount_encoded,
    'Credit_Mix_encoded': Credit_Mix_encoded,
    'Occupation_encoded': Occupation_encoded,
    'Payment_Behaviour_encoded':Payment_Behaviour_encoded,
    'Age': age, 
    'Annual_Income': annual_income,
    'Monthly_Inhand_Salary': monthly_inhand_salary,
    'Num_Bank_Accounts': num_bank_accounts,
    'Num_Credit_Card': num_credit_card,
    'Num_of_Loan': num_of_loan,
    'numberofdelayedpayments': num_of_delayed_payment,
    'Num_Credit_Inquiries': num_credit_inquiries,
    'Outstanding_Debt': outstanding_debt,
    'Total_EMI_per_month': total_emi_per_month ,
    'Amount_invested_monthly': amount_invested_monthly,
    'Monthly_Balance': monthly_balance,
    'Delay_from_due_date':delay_from_due_date
    }
    
    #creating numpy array
    ex1 = np.array(form_data).reshape(1,-1)
    output=model.predict(ex1)
    #predicted credit value
    prediction_string = f"You are eligible for a loan and ur credit score is {output[0]}"
    print(prediction_string)
    return render_template('res.html',prediction_string)
    

if __name__ == '__main__':
    app.run(debug=True)
