from flask import Flask, render_template, request
import pickle
# Load the trained model from the file
model=pickle.load(open('model.pkl','rb'))
app = Flask(__name__)

# Route for home page
@app.route('/')
def home():
    return render_template('home.html')

# Route for prediction
@app.route('/predict', methods=['POST'])
def predict():
    # Get input data
    age = float(request.form['age'])
    annual_income = float(request.form['annual_income'])
    monthly_inhand_salary = float(request.form['monthly_inhand_salary'])
    num_bank_accounts = float(request.form['num_bank_accounts'])
    num_credit_card = float(request.form['num_credit_card'])
    num_of_loan = float(request.form['num_of_loan'])
    delay_from_due_date =float(request.form['delay_from_due_date'])
    num_of_delayed_payment = float(request.form['num_of_delayed_payment'])
    num_credit_inquiries = float(request.form['num_credit_inquiries'])
    outstanding_debt = float(request.form['outstanding_debt'])
    total_emi_per_month = float(request.form['total_emi_per_month'])
    amount_invested_monthly = float(request.form['amount_invested_monthly'])
    monthly_balance = float(request.form['monthly_balance'])
    credit_score = float(request.form['credit_score'])
    occupation_encoded = int(request.form['occupation_encoded'])
    credit_mix_encoded = int(request.form['credit_mix_encoded'])
    payment_of_min_amount_encoded = int(request.form['payment_of_min_amount_encoded'])
    payment_behaviour_encoded = int(request.form['payment_behaviour_encoded'])

    # Perform prediction using the model
    # Replace the prediction logic with your model's prediction code
    prediction = 1  # Placeholder prediction

    return f'Prediction: {prediction}'

if __name__ == '__main__':
    app.run(debug=True)
